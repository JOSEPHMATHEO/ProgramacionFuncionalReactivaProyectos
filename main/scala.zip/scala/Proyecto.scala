package ec.edu.utpl.presencial.computacion.pfr.pintegra
import com.github.tototoshi.csv.*

import java.io.File

implicit object CustomFormat extends DefaultCSVFormat{
  override val delimiter: Char = ';'
}

object Proyecto {

  @main
  def work() =

    val path2DataFile: String = "C:/Users/sucol/OneDrive/Escritorio/dsPartidosYGoles.csv"
    val reader = CSVReader.open(new File(path2DataFile))
    //val contentFile: List[List[String]] = reader.all()
    val contentFile: List[Map[String, String]] = reader.allWithHeaders()

    reader.close()

    //println(contentFile.take(1)(0)("tournaments_winner"))
    println(s"Filas: ${contentFile.length} y Columnas: ${contentFile(0).keys.size}")
    // Maxima Capacidad

    println(
      contentFile
        .map(
          x => x("stadiums_stadium_name") -> x("stadiums_stadium_capacity"))
        .distinct
        .maxBy(_._2.toInt)

    )


    // Minima Capacidad

    println(
      contentFile
        .map(
          x => x("stadiums_stadium_name") -> x("stadiums_stadium_capacity"))
        .distinct
        .maxBy(_._2.toInt)

    )

    //



  /*@main
  def work2() =

    val path2DataFile: String = "C:/Users/sucol/OneDrive/Escritorio/dsAlineacionesXTorneo.csv"
    val reader2 = CSVReader.open(new File(path2DataFile))
    //val contentFile: List[List[String]] = reader.all()
    val contentFile: List[Map[String, String]] = reader2.allWithHeaders()

    reader2.close()

    print(contentFile.take(1))
    //println(s"Filas: ${contentFile.length} y Columnas: ${contentFile(0).keys.size}")*/

}

